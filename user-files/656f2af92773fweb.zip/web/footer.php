<footer class="footer">
    <div class="container">
        <div class="footer__row">
            <a href="mailto:info@gmail.com" class="footer__email">info@gmail.com</a>
            <div class="footer__developer-info">Информация о разработчике</div>
        </div>
    </div>
</footer>
<script src="assets/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</body>
</html>